void diff_key16diff_key7_1()
{
  if (!strcmp(_op_buf_, "passwd"))
  {
    (*_op_str_op_)(sink_data, "secret");
    sink_mtd();
  }

}

