void diff_key16diff_key7_2(const char *_op_buf_, char *_op_str_op_(char *, const char *), char **_main_argv_, int main_return_)
{
  if (!strcmp(_op_buf_, "passwd"))
  {
    (*_op_str_op_)(sink_data, "secret");
    sink_mtd();
  }

  op_label_:
  printf("##\n");

  dump();
  printf("%s\n", sink_data);
}

